package model

data class ChatMessage(val text: String, val isSender: Boolean)