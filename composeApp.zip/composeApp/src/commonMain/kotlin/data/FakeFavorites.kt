package data

import model.Destination

object FakeFavorites {
    val favorites = mutableListOf<Destination>()
}