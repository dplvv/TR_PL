package data

import model.Destination

object FakeCart {
    val cartItems = mutableListOf<Destination>()
}